const url = "https://api.openweathermap.org/data/2.5/weather?zip=16801&appid=996da84bacdaed7a0bbfd52e0243ef35&units=imperial";
const REFRESH_SECONDS = 15;
let secondsUntilRefresh = REFRESH_SECONDS + 1;
// He said stuff at 17:20 that doesn't make sense to me right now TODO


document.addEventListener("DOMContentLoaded", async () =>
{
    const data = await getWeatherData();
    modifyPage(data);

    await refreshManager();
});

async function getWeatherData() {
    // You generally want to put fetch calls in a try catch in case of network errors
    try
    {
        const results = await fetch(url);
        console.log(results);
        // Tells us about the response object

        if(results.ok === false)
        {
            throw new Error(results.statusText)
            // Checking if the response is giving us an OK status code.

        }

        const data = await results.json();
        // Converts the results from a json string to a json object
        // It is standard typically that APIs return JSON

        console.log(data);
        return data;
    }
    catch (err)
    {
        console.error(err);
        throw new Error(err.message); // Forces the code to stop so we do not process any further.
    }
}

// Only gets called when we have data, only will execute when the data changes/page is refreshed
// Function must complete first before the changes show.
function modifyPage(data)
{
    document.getElementById("page-loading").style.display = "none";
    revealAll();

    document.title = `Weather in ${data.name}`;
    // Changing the tab's title

    document.getElementById("header").innerText = `Weather in ${data.name}`;
    document.getElementById("temperature").textContent = `Temperature: ${data.main.temp}°F`;
    document.getElementById("feels-like").textContent = `Feels Like: ${data.main.feels_like}°F`;
    document.getElementById("low-temp").textContent = `Low Temperature: ${data.main.temp_min}`;
    document.getElementById("high-temp").textContent = `High Temperature: ${data.main.temp_max}`;
    document.getElementById("humidity").textContent = `Humidity: ${data.main.humidity}%`;
    document.getElementById("wind").textContent = `Wind: ${data.wind.speed}mph ${degreeToCompass(data.wind.deg)}`;
    document.getElementById("sunrise").textContent = `Sunrise: ${secondsSinceEpochToTime(data.sys.sunrise)}`;
    document.getElementById("sunset").textContent = `Sunset: ${secondsSinceEpochToTime(data.sys.sunset)}`;
}


async function refreshManager() {
    if (--secondsUntilRefresh <= 0)
    {
        setTimeout(()=>
        {
            document.getElementById('refresh-timer').textContent = "Refreshing...";
            // After 0 ms, the browser runs this code whether getWeatherData has returned or not.

        }, 0);
        // JavaScript is single threaded on the UI thread
        // When a function is in effect, UI changes DO NOT HAPPEN UNTIL THE FUNCTION RETURNS
        // This is decoupling, we could change refresh-timer's text content 1000 times
        // ... but only the last one will show because the function does not return until we know
        // ... what should be here, and it has been decoupled.

        const data = await getWeatherData();
        modifyPage(data);
        secondsUntilRefresh = REFRESH_SECONDS;
    }

    document.getElementById('refresh-timer').textContent = `Refreshing in ${secondsUntilRefresh} seconds...`;

    setTimeout(refreshManager, 1000);


    // Screen will only be repainted once the entire function (get weather data) returns
    // We need to decouple this
}

function secondsSinceEpochToTime(time)
{
    const date = new Date(time * 1000);
    // Dates want a time in ms, we passed in seconds so ms=1000*s

    return date.toLocaleTimeString('en-US',
        {
           hour: 'numeric',
           minute: 'numeric',
           hour12: true
        });
}



function degreeToCompass(degree)
{
    // Normalize the degree to ensure it is within 0-360
    degree = degree % 360;

    if (degree < 0) {
        degree += 360;
    }

    if (degree >= 337.5 || degree < 22.5)
    {
        return 'N';
    }
    else if (degree >= 22.5 && degree < 67.5)
    {
        return 'NE';
    }
    else if (degree >= 67.5 && degree < 112.5)
    {
        return 'E';
    }
    else if (degree >= 112.5 && degree < 157.5)
    {
        return 'SE';
    }
    else if (degree >= 157.5 && degree < 202.5)
    {
        return 'S';
    }
    else if (degree >= 202.5 && degree < 247.5)
    {
        return 'SW';
    }
    else if (degree >= 247.5 && degree < 292.5)
    {
        return 'W';
    }
    else
    {
        return 'NW';
    }
}


// Remove placeholders so we can put data in.
function revealAll()
{
    const placeholders = document.querySelectorAll(".placeholder");

    for(let ph of placeholders)
    {
        ph.style.display = "none";
    }
}

