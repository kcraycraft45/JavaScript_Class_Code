// When using jquery, ecmascript modules don't play nicely.
// This is a commonJS file
// We import it as a src, do not specify type="module"

$(document).ready(function()
{
   $('#add-task-btn').click(function()
   {
       // Listening for clicks calls the function in this body
       const task = $('#task-input').val(); // Warnings are normal because it does not know jQuery
       if(task !== '')
       {
           // Create a new li element
           let newTaskElement = $('<li>').text(task);
           $('#task-list').append(newTaskElement);
           $('#task-input').val(''); // val() is a getter and a setter depending on the context it is used in

           updateTaskCount();
       }
   });

   // If a user clicks on li item
    $(document).on('click', 'li', function()
    {
       // in jQuery, 'this' refers to the element that triggered the event.
        // If class exists, remove it, if it doesn't, create it
       $(this).toggleClass('completed');

       //.toggle toggles the element's visibility on the page.
       updateTaskCount();
    });

    $('#clear-completed-btn').click(function()
    {
       $('#task-list .completed').remove();
       // The space indicates that we are looking for all CHILDREN
        // WIthout the space, we are looking at the element beforehand
        updateTaskCount();
    });

    // all inputs that have the name task filter
    $('input[name="task-filter"]').change(function()
    {
       // Essentially selected all of our radio buttons
       // Which filter is currently being used?
       const filterValue = $(this).val();

       // This is the element that was triggered
        if(filterValue === 'all')
        {
            $('#task-list li').show(); // Show all the li's
        }
        else if(filterValue === 'completed')
        {
            $('#task-list li.completed').show(); // Show completed li's
            $('#task-list li:not(.completed)').hide();
        }
        else if(filterValue === 'active')
        {
            $('#task-list li.completed').hide();
            $('#task-list li:not(.completed)').show();
        }

    });

});


function updateTaskCount()
{
    const totalTasks = $('#task-list li').length;
    const completedTasks = $('#task-list li.completed').length;

    $('#task-count').text(`${totalTasks} tasks total, ${completedTasks} completed`)
    // .text() is also a getter and setter.

}
